const chalk = require("chalk");
const log = console.log;
const checkNumber = require("./utils/checkNumber");
var fs = require('fs');
const { stringify } = require('csv-stringify');

(async () => {
	fs.readFile('phone_numbers.txt', 'utf8', async (error, data) => {
		if (error) {
			console.error('An error occurred while reading the file:', error);
			return;
		}
		console.log('File content:', data.split('\n'));
		let detail = data.split('\n')
		
		for (let i = 0; i < detail.length; i++) {
			let phoneNumber = detail[i].replace(/(\r\n|\n|\r)/gm, "")
			// await checkNumberBulk(detail[i].replace(/(\r\n|\n|\r)/gm, ""))
			log(chalk.blue(`Checking for Existence : ${phoneNumber}`));
			const numberExists = await checkNumber(phoneNumber);

			if (numberExists === 'Network Issue') {
				// issueResults.push([phoneNumber, 'Network Issue'])
				fs.appendFile('NetworkIssue.txt', `${phoneNumberi}\n`, 'utf8', (error) => {
					if (error) {
						console.error('An error occurred while writing to the file:', error);
						return;
					}
					console.log('File has been written successfully.');
				});
			} else {
				console.log('status', [phoneNumber, numberExists ? 'valid' : 'invalid'])
				// results.push([phoneNumber, numberExists ? 'valid' : 'invalid'])

				if (numberExists) {
					log(chalk.green.bold("1-Number Exists on Whatsapp"));
					fs.appendFile('valid.txt', `${phoneNumber}\n`, 'utf8', (error) => {
						if (error) {
							console.error('An error occurred while writing to the file:', error);
							return;
						}
						console.log('File has been written successfully.');
					});
				} else {
					log(chalk.red.bold("1-Number doesn't exist on Whatsapp"));
					fs.appendFile('invalid.txt', `${phoneNumber}\n`, 'utf8', (error) => {
						if (error) {
							console.error('An error occurred while writing to the file:', error);
							return;
						}
						console.log('File has been written successfully.');
					});
				}

			}

		}

		
	})

	// if (process.argv.length < 3) {
	// 	log(chalk.red.bold("No Phone Number has been passed"));
	// 	log(chalk.blue("Example: npm run check 919898989898"));
	// 	process.exit(0);
	// }
	// const phoneNumber = process.argv[2];
	// log(chalk.blue(`Checking for Existence : ${phoneNumber}`));
	// const numberExists = await checkNumber(phoneNumber);
	// if (numberExists) log(chalk.green.bold("Number Exists on Whatsapp"));
	// else log(chalk.red.bold("Number doesn't exist on Whatsapp"));
	// process.exit(0);
})();
